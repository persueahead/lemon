package com;

public class Demo6 {

	public static int facorial1(int n) {
		int result = 1;
		for(int i=1;i<=n;i++) {
			result *=i;//result=result*i; 
		}
		return result;
	}
	
	//5!=5*4*3*2*1
	public static int facorial(int n) {
		if(n==1) {
			return 1;
		}
		int z = facorial(n-1);
		int s = n*z;
		//3*2*1
		return s;
	}
	
	public static void main(String[] args) {
		/**
		 *  facorial(3) = 3*facorial(2)
		 *  facorial(2) = 2*facorial(1)
		 *  facorial(1) = 1*facorial(0)
		 */
		int result = facorial(10);
		System.out.println(result);
		
	}
	
}
