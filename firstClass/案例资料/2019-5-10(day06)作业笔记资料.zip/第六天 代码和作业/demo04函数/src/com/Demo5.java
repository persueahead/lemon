package com;

public class Demo5 {

	public static int sum(int a,int b) {
		return a+b;
	}
	
	public static double sum(double a,double b) {
		return a+b;
	}
	
	public static int sum(int a,int b,int c) {
		return a+b+c;
	}
	
	public static void main(String[] args) {
		
		int s1 = sum(5,3);
		int s3 = sum(5,3,4);
		double s2 = sum(5.3,3.3);
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}
	
}
