package com.nm1;

public interface A {

	public void testA();
}
