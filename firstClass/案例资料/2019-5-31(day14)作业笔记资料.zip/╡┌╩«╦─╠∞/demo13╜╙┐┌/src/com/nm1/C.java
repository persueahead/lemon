package com.nm1;

public interface C  extends A,B{

	public void testC();
}
