package com.nm1;

public interface B {

	public void testB();
}
