package com.nm2.impl;

import com.nm2.UserDAO;
import com.nm2.po.UserInfo;

/**
 *    �����ʵ��
 * @author Administrator
 *
 */
public class UserMysqlDAOImpl implements UserDAO {

	@Override
	public void add(UserInfo user) {
		System.out.println("Mysql�����û���"+user.toString());		
	}

	@Override
	public void update(UserInfo user) {
		System.out.println("Mysql�޸��û���"+user.toString());		
	}

	@Override
	public void delete(UserInfo user) {
		System.out.println("Mysqlɾ���û���"+user.toString());		
		
	}

	@Override
	public UserInfo query(int userId) {
		System.out.println("Mysql��ѯ");
		//ģ�����ݿ��ѯ
		if(userId == 1001) {
			UserInfo user = new UserInfo();
			user.setUserId(1001);
			user.setUserName("����");
			user.setUserSex("��");
			user.setUserAge(18);
			return user;
		}
		
		return null;
	}

}
