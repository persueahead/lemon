package com.nm2.po;

/** ��Java����
 * �û���Ϣ����
 * @author Administrator
 *
 */
public class UserInfo {

	//�û����
	private int userId;
	
	//�û�����
	private String userName;
	
	//�û��Ա�
	private String userSex;
	
	//�û�����
	private int userAge;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserSex() {
		return userSex;
	}

	public void setUserSex(String userSex) {
		this.userSex = userSex;
	}

	public int getUserAge() {
		return userAge;
	}

	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}

	/**
	 * ������е�������Ϣ
	 */
	@Override
	public String toString() {
		return "UserInfo [userId=" + userId + ", userName=" + userName + ", userSex=" + userSex + ", userAge=" + userAge
				+ "]";
	}
	
	
}
