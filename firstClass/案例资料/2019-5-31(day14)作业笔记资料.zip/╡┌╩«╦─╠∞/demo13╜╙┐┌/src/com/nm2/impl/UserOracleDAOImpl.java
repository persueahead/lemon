package com.nm2.impl;

import com.nm2.UserDAO;
import com.nm2.po.UserInfo;

/**
 *    �����ʵ��
 * @author Administrator
 *
 */
public class UserOracleDAOImpl implements UserDAO {

	@Override
	public void add(UserInfo user) {
		System.out.println("Oracle�����û���"+user.toString());		
	}

	@Override
	public void update(UserInfo user) {
		System.out.println("Oracle�޸��û���"+user.toString());		
	}

	@Override
	public void delete(UserInfo user) {
		System.out.println("Oracleɾ���û���"+user.toString());		
		
	}

	@Override
	public UserInfo query(int userId) {
		System.out.println("Oracle��ѯ");
		//ģ�����ݿ��ѯ
		if(userId == 1001) {
			UserInfo user = new UserInfo();
			user.setUserId(1001);
			user.setUserName("����");
			user.setUserSex("��");
			user.setUserAge(18);
			return user;
		}
		
		return null;
	}

}
