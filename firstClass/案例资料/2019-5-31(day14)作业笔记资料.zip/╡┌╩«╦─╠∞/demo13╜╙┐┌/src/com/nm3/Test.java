package com.nm3;

public class Test {

	public static void main(String[] args) {
		
		A.B b = new A().new B(); 
		b.test1();
		
	}
}
class A{
	class B{
		
		public void test1() {
			System.out.println("-----------");
		}
	}
	
}
