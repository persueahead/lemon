package com.nm3;

public class Demo04 {

	private String name = "����";
	
	
	USB usb = new USB() {

		@Override
		public void intall() {
			System.out.println("�����ڲ��ࣺ"+name);
			
		}

		@Override
		public void work() {
			System.out.println("---����--");
			
		}
		
	};
	
	public void test() {
		
		final String names= "lisi";

		System.out.println("---����--");
		
		/**
		 * �����ڲ���
		 */
		new Animal() {

			@Override
			public void eat() {
				
				System.out.println("------�Զ����ķ���----"+names);
				
			}
			
		}.eat() ;
	}
	
	public static void main(String[] args) {
		Demo04 de = new Demo04();
		de.usb.intall();
		de.usb.work();
		de.test();
	}
}

abstract class Animal{
	public abstract void eat();
}

interface USB{
	public void intall();
	
	public void work();
}

