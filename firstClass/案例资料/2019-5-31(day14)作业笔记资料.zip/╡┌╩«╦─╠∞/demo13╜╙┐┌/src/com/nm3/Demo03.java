package com.nm3;

public class Demo03 {

	
	public static void main(String[] args) {
		new Outer2().new Inter2().show(); //����
	}
}
class Outer2{

	class Inter2{
		
		
		public void show() {
			System.out.println("�ڲ���Ĳ��Է���.....");
		}
	}
	
}

