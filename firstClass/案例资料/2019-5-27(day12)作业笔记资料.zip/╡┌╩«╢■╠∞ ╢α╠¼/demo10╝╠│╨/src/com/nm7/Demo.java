package com.nm7;

import com.nm6.Person;;

public class Demo {
	
	public String name ="����";
	
	public void test() {
	
		System.out.println("���԰���"+name);
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		test.demo();
		
		Son son = new Son();
		son.eat();
		
		Person p = new Person();
		p.speak();
		
		
	}
}
