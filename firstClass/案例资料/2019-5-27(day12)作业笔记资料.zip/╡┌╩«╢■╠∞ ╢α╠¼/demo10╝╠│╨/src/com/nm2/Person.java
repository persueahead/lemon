package com.nm2;

/**
 * �˵���
 * @author Administrator
 *  �鿴��Ĺ�ϵ control+t
 */
public class Person extends Object {

	//����
	 String name;
	
	//����
	private int age;
	
	//�Ա�
	private String sex;
	
	//��ͥ��ַ
	private String address;
	
	/*
	 * public Person(String name,int age) { this.name = name; this.age = age; }
	 */
	/**
	 * �Է��ķ���
	 */
	public void eat() {
		System.out.println("--------��ÿ����Ҫ�Է�-------");
	}

	public String getName() {
		
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
