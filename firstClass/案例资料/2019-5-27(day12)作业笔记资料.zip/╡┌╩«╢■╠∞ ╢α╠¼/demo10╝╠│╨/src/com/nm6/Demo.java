package com.nm6;

public class Demo {

	public static void main(String[] args) {
		
		ChinaPerson person = new ChinaPerson();
		person.speak();
		person.run();
		System.out.println("----------------");
		AmericanPerson p2 =new AmericanPerson();
		p2.speak();
		p2.run();
		
	}
}
