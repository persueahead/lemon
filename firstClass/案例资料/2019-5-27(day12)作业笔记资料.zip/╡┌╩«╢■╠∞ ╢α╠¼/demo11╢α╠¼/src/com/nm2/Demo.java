package com.nm2;

public class Demo {

	public static void main(String[] args) {
		
		Brid maque = new MaQue();
		maque.eat();
		
		
		Brid laoying = new LaoYing();
		laoying.eat();
		
	}
}
