package com.nm4;



public class Demo {

	public static void main(String[] args) {
		B b = new B();
		b.put(new A());
	}
}
