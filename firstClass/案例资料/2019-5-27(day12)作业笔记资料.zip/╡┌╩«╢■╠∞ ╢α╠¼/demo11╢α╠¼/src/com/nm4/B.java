package com.nm4;

public class B {

	
	public void put(A a) {
		a.say();
	}
}
