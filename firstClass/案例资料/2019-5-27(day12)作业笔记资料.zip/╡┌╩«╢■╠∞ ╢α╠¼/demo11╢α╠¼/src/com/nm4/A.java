package com.nm4;

public class A {
	public void say() {
		System.out.println("-------A˵��----");
	}
}
