package com.nm3;

public class Demo {
	
	public static void main(String[] args) {
		//��̬
		User user = new UserMysql();//new UserOracle();
		user.add();
		
	}

}
