package com.nm5;

public class C {

	
	public void put(Fu fu) {
		fu.say();
	}
}
