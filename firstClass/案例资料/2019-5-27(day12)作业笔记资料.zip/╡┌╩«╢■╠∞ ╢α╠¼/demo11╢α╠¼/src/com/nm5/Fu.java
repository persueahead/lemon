package com.nm5;

public class Fu {

		public void say() {
			
		}
}
