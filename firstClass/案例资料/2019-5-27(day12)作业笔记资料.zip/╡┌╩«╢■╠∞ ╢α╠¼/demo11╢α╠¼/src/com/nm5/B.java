package com.nm5;

public class B extends Fu{

	@Override
	public void say() {
		System.out.println("-----B˵��----");
	}

	public void info() {
		
	}
	
}
