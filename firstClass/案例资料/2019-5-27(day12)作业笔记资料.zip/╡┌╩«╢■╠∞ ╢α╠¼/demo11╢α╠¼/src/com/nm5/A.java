package com.nm5;

public class A extends Fu {

	@Override
	public void say() {
		System.out.println("-------A˵��------");
	}

	
	
}
