package com.nm5;

public class Demo {

	public static void main(String[] args) {
		
		//��̬ ����
		Fu fu =  new B();
		fu.say();
		C c = new C();
		c.put(fu);

	}

}
