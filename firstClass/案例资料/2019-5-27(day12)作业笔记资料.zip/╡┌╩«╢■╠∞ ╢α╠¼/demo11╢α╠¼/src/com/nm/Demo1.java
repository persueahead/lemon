package com.nm;

public class Demo1 {

	/**
	 * ���
	 * @param a
	 * @param b
	 * @return
	 */
	public int getSum(int a,int b) {
		return a+b;
	}
	
	/**
	 * ���������
	 * @param a
	 * @param b
	 * @param c
	 * @return
	 */
	public int getSum(int a,int b,int c) {
		return a+b+c;
	} 
	
	
	public static void main(String[] args) {
		Demo1 demo = new Demo1();
		System.out.println(demo.getSum(10, 20));
		System.out.println(demo.getSum(10, 20,30));
	}
}
