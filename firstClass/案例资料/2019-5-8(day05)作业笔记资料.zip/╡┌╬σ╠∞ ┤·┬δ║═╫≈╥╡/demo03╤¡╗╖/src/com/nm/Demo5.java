package com.nm;

public class Demo5 {

	public static void main(String[] args) {
		int i = 0;
		while(true) {
			System.out.println(i);
			i++;
		}
		
	
	}

}
