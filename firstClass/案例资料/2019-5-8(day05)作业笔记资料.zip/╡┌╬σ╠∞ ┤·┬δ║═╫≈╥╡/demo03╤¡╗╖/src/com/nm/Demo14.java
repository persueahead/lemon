package com.nm;

public class Demo14 {

	public static void main(String[] args) {
		for(int i=1;i<5;i++) {
			
			for(int j=0;j<5-i;j++) {
				System.out.print("-");
			}
			
			/**
			 * 1 1=2*1-1  4=5-1
			 * 2 3=2*2-1  3=5-2 
			 * 3 5=2*3-1  2=5-3
			 */
			for(int j=0;j<2*i-1;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	

	}

}
