package com.nm;

public class Demo8 {

	public static void main1(String[] args) {
		for(int i = 0;i<100;i++) {
			System.out.println("*");
		}
		
		for(int i = 0;i<15;i++) {
			System.out.println("*");
		}
	}
	public static void main(String[] args) {

/*		for(int i =0;i<10;i++) {
			System.out.println(i);
		}
		System.out.println("------------------");
		int i=0;
		for(;i<10;i++) {
			System.out.println(i);
		}
		System.out.println("------------------");
		int j=0;
		for(;j<10;) {
			System.out.println(j);
			j++;
		}*/
		
		  System.out.println("------------------"); 
		  for(int i=10;i-->0;System.out.println(i)) {
		  
		  }
		  
		  
		  for(int i=15;i-->0;) { System.out.println(i);
		  
		  }
		 
		
		for(System.out.println(1);;System.out.println(2)) {
			System.out.println(3);
		}
		
	}
}
