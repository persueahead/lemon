package com.nm;

import java.util.Scanner;

public class Demo10 {

	public static void main(String[] args) {
		for(int i = 0;i<1000;i++) {
			//���Ʊ���������ͬ
			for(int j=1;j<1000;j++) {
				System.out.println(i+"  "+j);
			}
		}
		
		
	}
}
