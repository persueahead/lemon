package person;

public class Test {

	public static void main(String[] args) {
		Student s1 = new Student();
		Student s2 = new Student();
		Student s3 = new Student();
		s1.id = 1001;
		s1.num=111;
		
		System.out.println(s1.id +"  "+s1.num);
		System.out.println(s2.id +"  "+s2.num);
		System.out.println(s3.id +"  "+s3.num);
	}
	
}

class Student{
	
	//���
	int id;
	
	//����
	static int num = 0;
		
}