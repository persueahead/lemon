package com;

import java.util.Arrays;

/**
 * ���л���
 * @author Administrator
 *
 */
public class Demo01 {

	
	public static int[][] f(int[][] arr){
		int rows = arr.length;//3
		int cols = arr[0].length;//4
		
		int[][] result = new int[cols][rows];
		for(int i = 0 ;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				result[j][i]=arr[i][j]; 
				//result[0][0]=1 a[0][0]=1 
				//result[1][0] =2 a[0][1]=2 
				//result[2][0] =3 a[0][2]=3
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		int[][] arr = {{1,2,3},
					   {4,5,6},
					   {7,8,9}}; // [3][4]
		
		int[][] result = f(arr);
		System.out.println(Arrays.deepToString(result));
		
	}
}
