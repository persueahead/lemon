package com;

public class Demo2 {
	
	
	public static void printArr(int[][] arr) {
		for(int i = 0;i<arr.length;i++) {
			int[] innerArr = arr[i];
			for(int j=0;j<innerArr.length;j++) {
				System.out.print(innerArr[j]+",");
			}
			System.out.println();
		}
		
	}
	
	public static void printArr2(int[][] arr) {
		for(int i =arr.length;i-->0;) {
			int[] innerArr = arr[i];
			for(int j=0;j<innerArr.length;j++) {
				System.out.print(innerArr[j]+",");
			}
			System.out.println();
		}
		
	}
	
	public static void printArr3(int[][] arr) {
		for(int i = 0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+",");
			}
			System.out.println();
		}
		
	}
	
	public static void printArr4(int[][] arr) {
		for(int i =arr.length;i-->0;) {
			for(int j=arr[i].length;j-->0;) {
				System.out.print(arr[i][j]+",");
			}
			System.out.println();
		}
		
	}
	
	public static void printArr5(int[][] arr) {
		for(int[] arr1:arr) {
			for(int a:arr1) {
				System.out.print(a+",");
			} 
			
			System.out.println();
		}
		
	}

	public static void main(String[] args) {
		int[][] arr =new int[5][3];
		arr[0][0] = 11;
		arr[0][1] = 22;
		arr[1][1] = 33;
		printArr5(arr);
	}
}
