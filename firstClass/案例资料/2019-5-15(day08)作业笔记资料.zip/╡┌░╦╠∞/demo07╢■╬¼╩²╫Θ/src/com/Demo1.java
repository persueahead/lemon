package com;

import java.util.Arrays;

public class Demo1 {

	public static void main1(String[] args) {
		
		/**
		 * [[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]]
		 */
		int[][] arr = new int[5][3];
		arr[1][1] = 9;//[[0,0,0],[0,9,0],[0,0,0],[0,0,0],[0,0,0]]
		int[] arr1 = arr[1]; //[0,9,0]
		arr1[1] = 8; //[0,8,0]
		System.out.println(arr[1][1]);
		int x = arr[0][0];
		
		System.out.println(x);
		
		
	}
	
	public static void main(String[] args) {
		
		/**
		 * ���������
		 * [null,null,null,null,null]
		 */
		int[][] arr = new int[5][];
		arr[0] = new int[3];  //[[0,0,0],null,null,null,null]
		arr[1] = new int[] {1,2,3};//[[0,0,0],[1,2,3],null,null,null]
		arr[3] = new int[]{1};//[[0,0,0],[1,2,3],null,[1],null]
		System.out.println(Arrays.toString(arr));
		
		
	}
}
