package com;

public class Demo3 {

	
	public static void main1(String[] args) {
		
		//��ǿ��forѭ��  for(:)
		int[] arr = {1,2,34,56,7};
		for(int i:arr) {
			System.out.println(i);
		}
		
		System.out.println("----------");
		for(int j =0;j<arr.length;j++) {
			int i = arr[j];
			System.out.println(i);
		}
		
		
		int[][] arr2 = new int[5][5];
		
		for(int[] arr3:arr2) {
			for(int a:arr3) {
				System.out.println(a);
			}
		}
		
	}
	
	public static void main3(String[] args) {
		
		String[] arr = {};
		/*
		 * for(int i = 0;i<arr.length;i++) { String name = arr[i];
		 * System.out.println(name); }
		 */
		System.out.println("------------");
		for(String name :arr) {
			System.out.println(name);
		}
	}
	
	public static void main(String[] args) {
		
		int[] arr = null;
		for(int i =0;i<arr.length;i++) {
			System.out.println(i);
		}
		
		for(int i :arr) {
			System.out.println(i);
		}
	}
}
