package com;

public class Demo1 {

	public static void f1(int a) {
		a = 1;//�ֲ�����
	}
	
	public static void main(String[] args) {
		int a = 0;
		f1(a);
		System.out.println(a);
	}
	
}
