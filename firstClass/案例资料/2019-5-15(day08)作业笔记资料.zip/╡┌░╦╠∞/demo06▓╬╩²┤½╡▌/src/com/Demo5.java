package com;

import java.util.Arrays;

public class Demo5 {

	
	public static void main(String[] args) {
		int[] arr = {2,5,1,25,64,23,11};
		//Arrays.sort(arr);
		System.out.println("��ʼֵ��"+Arrays.toString(arr));
		bubbleSort(arr);
		System.out.println(Arrays.toString(arr));
	}
	
	public static void bubbleSort(int[] arr) {
		for(int j =0 ;j<arr.length-1;j++) {
			for(int i=1;i<arr.length-j;i++) {
				if(arr[i-1]>arr[i]) {
					int temp = arr[i-1];
					arr[i-1] = arr[i];
					arr[i] = temp;
				}
			}
			
			System.out.println(Arrays.toString(arr));
		}
		
		
	}
	
	
}
