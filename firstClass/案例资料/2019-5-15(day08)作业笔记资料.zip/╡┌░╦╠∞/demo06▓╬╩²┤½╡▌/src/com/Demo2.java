package com;

import java.util.Arrays;

public class Demo2 {

	
	public static void f1(int[] arr2) {
		arr2[0] = 9;
		//arr2 = null;
	}
	
	public static void f2(int[] arr2) {
		arr2 = new int[4];//{0,0,0,0}
		System.out.println(Arrays.toString(arr2));
	}
	
	public static void main(String[] args) {
		int[] arr1 = new int[3];//{0,0,0}
		f1(arr1);
		System.out.println(Arrays.toString(arr1));
	}
	
}
