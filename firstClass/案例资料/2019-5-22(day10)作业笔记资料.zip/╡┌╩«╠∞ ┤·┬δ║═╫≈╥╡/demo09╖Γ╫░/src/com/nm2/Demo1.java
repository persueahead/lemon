package com.nm2;

public class Demo1 {

	public static void main(String[] args) {
		Phone phone = new Phone();
		phone.playGame();
		phone.brand = "oppo";
		System.out.println(phone.brand );
		
		Phone.playGame();
		
		System.out.println(phone.sccj);
	}
}
