package com.nm4;

public class Demo {

	
	public static void main(String[] args) {
		
		Student s1 = new Student();
		System.out.println(s1.toString());
		Student s2 = new Student("����");
		System.out.println(s2.toString());
	}
}
