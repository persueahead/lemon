package com.nm;

public class Teacher {

	
	public void info(Student stu) {
		stu.run();
	}
	
	
	public static void main(String[] args) {
		Teacher t = new Teacher();
		t.info(new Student());
	}
}
