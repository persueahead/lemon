package com.nm1;

/**
 * �û���
 * @author Administrator
 *
 */
public class UserInfo {

	//�û����
	private int userId;
	
	//�û�����
	private String userName;
	
	public UserInfo(int userId,String userName) {
		this.userId = userId;
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "UserInfo [userId=" + userId + ", userName=" + userName + "]";
	}
	
	/*
	 * @Override public String toString() { // TODO Auto-generated method stub
	 * return "���"+userId+" ����:"+userName; }
	 */
	
	
}
