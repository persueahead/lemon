package com.nm1;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Demo09 {

	public static void main(String[] args) {
		//��ȡ�����ʱ��
		long time1 = System.currentTimeMillis();
		System.out.println(time1);
		for(int i= 0;i<10;i++) {
			System.out.println(i);
		}
		long time2 = System.currentTimeMillis();
		System.out.println(time2);
		System.out.println(time2-time1);
		
		
		Date date = new Date();
		System.out.println(date);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String s = sdf.format(date);
		System.out.println(s);
	}
}
