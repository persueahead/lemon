package com.nm1;

public class Demo04 {

	public static void main(String[] args) {
		UserInfo user = new UserInfo(1001,"����");
		System.out.println(user);
		System.out.println(user.toString());
	}
}
