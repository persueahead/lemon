package com.nm1;

public class Demo03 {

	public static void main(String[] args) {
		Person p1 = new Person(1,"����");
		Person p2 = new Person(1,"����");
		System.out.println(p1 == p2);// �Ƚ��ڴ��ַ
		System.out.println(p1.equals(p2)); // �Ƚ��ڴ��ַ
		
		System.out.println(p1.getClass());
	
		
		Object o =  new Object();
		System.out.println(o.getClass());
		 
	}
	
}

class Person extends Object{
	
	private int id ;
	private String name;
	
	public Person() {}
	
	public Person(int id, String name) {
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public boolean equals(Object obj) {
		System.out.println("----------------");
	
		//if( obj instanceof Person) {
		if(obj.getClass() == this.getClass()) {
			Person p = (Person)obj;
			if(this.id== p.id  && this.name.equals(p.name)) {
				return true;
			}
			
		}
		
		return false;
	}
	
	
	
}