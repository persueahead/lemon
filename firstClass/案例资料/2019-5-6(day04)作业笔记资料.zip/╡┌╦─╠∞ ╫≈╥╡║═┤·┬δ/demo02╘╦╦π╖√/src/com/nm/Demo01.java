package com.nm;

public class Demo01 {

	public static void main(String[] args) {
		char c ='a'; //97 
		c = (char) (c^32);
		System.out.println(c);
		//A 65
	}

}
