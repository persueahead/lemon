package com.nm;

public class Demo13 {

	public static void main(String[] args) {
	  /**
	   * ÿ���������
	   */
		
		int year = 2000;
		int month = 2;
		int maxDays = 0;
		switch(month) {
		case 2 :
			//�ж��Ƿ�Ϊ����
			if(year%4==0&&year%100==0||year%400==0) {
				maxDays = 29;
			}else {
				maxDays = 28;
			}
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			maxDays = 30;
			break;
		default:
			maxDays = 31;
		}
		
		System.out.println(maxDays);
		
	}

}
