package com.nm;

public class Demo8 {

	public static void main(String[] args) {
		
		int a = 2;
		int b = 3;
		boolean b1 = (++a)>2 || (++b)>3; //3>2 true 4>3 true
		System.out.println(b1);
		System.out.println(a);
		System.out.println(b);
		
	}

}
