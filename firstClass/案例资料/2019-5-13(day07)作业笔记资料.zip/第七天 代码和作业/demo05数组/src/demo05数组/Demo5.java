package demo05����;

import java.util.Arrays;

public class Demo5 {

	
	public static void test1(int[] arr) {
		
	}
	
	public static void test2(int... arr) {
		System.out.println("����ĳ��ȣ�"+arr.length);
		if(arr.length>0) {
			/*
			 * for(int i=0;i<arr.length;i++) { System.out.println(arr[i]); }
			 */
			System.out.println(Arrays.toString(arr));
		}
	}
	
	
	public static void main(String[] args) {
		
		
		//test2();
		
		//int[] arr = new int[] {23,123,4332,5};
		//test2(arr);
		test2(23,123,43);
		
		test2(23,12,34,56,34,5546,657,345,23,1231,342,2);
		
		test2( new int[] {23,123,4332,5});
	}
	
}
