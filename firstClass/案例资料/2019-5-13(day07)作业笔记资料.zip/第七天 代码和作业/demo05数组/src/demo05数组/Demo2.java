package demo05����;

public class Demo2 {

	public static void main(String[] args) {
		int[] arr = new int[5];//{0,0,0,0,0}
		//��ֵ
		arr[0] = 1;//{1,0,0,0,0}
		arr[arr.length-1] = 2;//{1,0,0,0,2}
		//arr[5] = 3; //�����±�Խ��
		
		//ȡֵ
		int a = arr[1];//0
		int b = arr[arr.length-1];//2
		//int c = arr[100];//
		
		
	}
}
