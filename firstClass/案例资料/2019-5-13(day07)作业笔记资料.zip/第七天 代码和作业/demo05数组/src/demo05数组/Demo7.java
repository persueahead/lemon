package demo05����;

public class Demo7 {

	public static void main(String[] args) {
		StringBuilder s1  = new StringBuilder("abc");
		s1.append("���");
		//s1.insert(0,'1');
		System.out.println(s1.toString());
		
		StringBuffer s2 = new StringBuffer();
		s2.append("ass");
		System.out.println(s2);
		
		String s = "abc";
		s=s+"���";// new StringBuilder().append(s).append("abc");
		System.out.println(s);
		
		int a = 12;
		
	}
}
