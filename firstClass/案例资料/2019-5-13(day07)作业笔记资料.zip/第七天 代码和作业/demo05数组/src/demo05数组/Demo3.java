package demo05����;

public class Demo3 {

	
	public static void main(String[] args) {
		int[] arr = new int[10];
		//��ֵ
		for(int i =0;i<arr.length;i++) {
			arr[i] =(int)(Math.random()*100);
		}
		
		//����
		//����
		for(int i =0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		System.out.println("-------------");
		//����
		/*
		 * for(int i=arr.length;i-->0;) 
		 * { System.out.println(arr[i]); }
		 */
		for(int i = arr.length-1;i>0;i--) {
			System.out.println(arr[i]);
		}
	}
}
