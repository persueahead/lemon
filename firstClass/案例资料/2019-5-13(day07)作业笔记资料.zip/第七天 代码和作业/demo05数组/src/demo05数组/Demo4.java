package demo05����;

import java.util.Arrays;

public class Demo4 {

	
	public static void main(String[] args) {
		/*int[] arr = new int[10];
		//��ֵ
		for(int i =0;i<arr.length;i++) {
			arr[i] =(int)(Math.random()*100);
		}
		
		//����
		for(int i =0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		System.out.println("-------------");
		//����
		Arrays.sort(arr);
		for(int i =0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		//������ַ�����ʾ
		String sarr = Arrays.toString(arr);
		System.out.println(sarr);
		
		int[] newarr2 = Arrays.copyOf(arr, 5);
		String s2 = Arrays.toString(newarr2);
		System.out.println(s2);
		*/
		//���: ���Ϊ7��7��7
		int[] arr3 = new int[3];
		Arrays.fill(arr3,7);
		String s = Arrays.toString(arr3);
		System.out.println(s);
		
	}
}
