package com.nm4;

public class Demo {

	
	public static void main(String[] args) {
		Dog dog = new Dog("����",10,"ĸ��");
		System.out.println(dog);
		System.out.println(dog.toString());
		//dog.eat();
		//dog.shout();
		
		//Erha erha = new Erha();
		//erha.eat();
	}
}
