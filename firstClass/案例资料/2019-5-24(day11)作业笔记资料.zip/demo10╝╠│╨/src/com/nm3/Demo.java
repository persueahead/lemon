package com.nm3;

public class Demo {

	
	public static void main(String[] args) {
		Animal an = new Animal();
		an.name="����";
		an.age=5;
		an.eat();
		an.shout();
		System.out.println("--------------");
		
		Dog dog = new Dog();
		dog.name="�Ŷ�";
		dog.eat();
		dog.shout();
		
		System.out.println("--------------");
		Cat cat = new Cat();
		cat.name="t��ķ";
		cat.eat();
		cat.shout();
		
		System.out.println("--------------");
		Pig pig = new Pig();
		pig.name="����С��";
		pig.eat();
		pig.shout();
	}
}
