/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2019/11/7 22:25:42                           */
/*==============================================================*/


drop table if exists Relationship_8;

drop table if exists menu;

drop table if exists t_audit_recoud;

drop table if exists t_cost;

drop table if exists t_expemse;

drop table if exists t_expemse_detail;

drop table if exists t_role;

drop table if exists t_salary_record;

drop table if exists t_users;

/*==============================================================*/
/* Table: Relationship_8                                        */
/*==============================================================*/
create table Relationship_8
(
   menuId               int not null,
   roleId               int not null,
   primary key (menuId, roleId)
);

/*==============================================================*/
/* Table: menu                                                  */
/*==============================================================*/
create table menu
(
   menuId               int not null auto_increment,
   menuName             varchar(25),
   pMenuId              int,
   menuUrl              varchar(33),
   primary key (menuId)
);

/*==============================================================*/
/* Table: t_audit_recoud                                        */
/*==============================================================*/
create table t_audit_recoud
(
   auditId              int not null auto_increment,
   usersId              int,
   expemseId            int,
   auditState           varchar(5),
   auditSugg            varchar(88),
   auditDate            datetime,
   primary key (auditId)
);

/*==============================================================*/
/* Table: t_cost                                                */
/*==============================================================*/
create table t_cost
(
   costId               int not null auto_increment,
   costName             varchar(30),
   costDesc             varchar(66),
   costMrak             varchar(5) default '0',
   primary key (costId)
);

/*==============================================================*/
/* Table: t_expemse                                             */
/*==============================================================*/
create table t_expemse
(
   expemseId            int not null auto_increment,
   usersId              int,
   expemseIdName        varchar(25),
   expemseIdDesc        varchar(99),
   expemseToltel        float(8),
   expemseState         varchar(5),
   expemseDate          datetime,
   primary key (expemseId)
);

/*==============================================================*/
/* Table: t_expemse_detail                                      */
/*==============================================================*/
create table t_expemse_detail
(
   expemseId            int auto_increment,
   costId               int,
   detailId             int,
   detailName           varchar(25),
   detailMonery         float(8)
);

/*==============================================================*/
/* Table: t_role                                                */
/*==============================================================*/
create table t_role
(
   roleId               int not null auto_increment,
   roleName             varchar(25),
   primary key (roleId)
);

/*==============================================================*/
/* Table: t_salary_record                                       */
/*==============================================================*/
create table t_salary_record
(
   salaryId             int not null auto_increment,
   usersId              int,
   salaryMonth          datetime,
   salaryDate           datetime,
   salaryComm           float(8),
   salaryBasic          float(8),
   primary key (salaryId)
);

/*==============================================================*/
/* Table: t_users                                               */
/*==============================================================*/
create table t_users
(
   usersId              int not null auto_increment,
   roleId               int,
   usersName            varchar(15),
   usersAge             int,
   usersPhone           varchar(11),
   usersSalary          float(8),
   usersAccout          varchar(25),
   usersPwd             varchar(38),
   usersMrak            varchar(5) default '0',
   primary key (usersId)
);

alter table Relationship_8 add constraint FK_Relationship_8 foreign key (menuId)
      references menu (menuId) on delete restrict on update restrict;

alter table Relationship_8 add constraint FK_Relationship_9 foreign key (roleId)
      references t_role (roleId) on delete restrict on update restrict;

alter table t_audit_recoud add constraint FK_Relationship_5 foreign key (expemseId)
      references t_expemse (expemseId) on delete restrict on update restrict;

alter table t_audit_recoud add constraint FK_Relationship_6 foreign key (usersId)
      references t_users (usersId) on delete restrict on update restrict;

alter table t_expemse add constraint FK_Relationship_2 foreign key (usersId)
      references t_users (usersId) on delete restrict on update restrict;

alter table t_expemse_detail add constraint FK_Relationship_3 foreign key (expemseId)
      references t_expemse (expemseId) on delete restrict on update restrict;

alter table t_expemse_detail add constraint FK_Relationship_4 foreign key (costId)
      references t_cost (costId) on delete restrict on update restrict;

alter table t_salary_record add constraint FK_Relationship_1 foreign key (usersId)
      references t_users (usersId) on delete restrict on update restrict;

alter table t_users add constraint FK_Relationship_7 foreign key (roleId)
      references t_role (roleId) on delete restrict on update restrict;

