package com.java.test;

import java.io.IOException;

public class Student  implements Runnable{
	@Override
	public void run() {
		//写上你业务逻辑
		System.out.println("public class Student  implements Runnable");
	}
}
